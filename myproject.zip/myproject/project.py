from flask.app import Flask
from flask.globals import request
from flask.templating import render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///new2.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=True
db=SQLAlchemy(app)
class empty:
     m=object
     l=object
     pass
class menu(db.Model):
     __tablename__='menu_tbl'
     id=db.Column(db.Integer,db.Sequence('seq_menu',start=101),primary_key=True)
     idly=db.Column(db.Integer)
     dosai=db.Column(db.Integer)
     masaldosai=db.Column(db.Integer)
     oniondosai=db.Column(db.Integer)
     parotta=db.Column(db.Integer)
     chappathi=db.Column(db.Integer)
     chickennoodles=db.Column(db.Integer)
     eggnoodles=db.Column(db.Integer)
     chickenfriedrice=db.Column(db.Integer)
     eggfriedrice=db.Column(db.Integer)
     chickenbriyani=db.Column(db.Integer)
     eggbriyani=db.Column(db.Integer)
     muttonbriyani=db.Column(db.Integer)
     chillichicken=db.Column(db.Integer)
     totalamount=db.Column(db.Integer)
     name=db.Column(db.String(25))
     email=db.Column(db.String(25))
     phoneno=db.Column(db.String(25))
     address=db.Column(db.String(50))
     pincode=db.Column(db.String(25))
     #locId=db.Column(db.Integer,db.ForeignKey("location_tbl.id"))
     #loc=db.relationship("location",back_populates="me")
     def __repr__(self):
          return "<menu({},{},{},{},{},{},{},{},{},{},{},{},{},{},{},{})>".format(self.id,self.idly,self.dosai,
                                                  self.masaldosai,self.oniondosai,self.parotta,self.chappathi,\
                                                  self.eggfriedrice,self.chickenfriedrice,self.eggnoodles,self.chickennoodles,\
                                                  self.eggbriyani,self.chickenbriyani,self.muttonbriyani,self.chillichicken,\
                                                  self.totalamount)
     
'''class location(db.Model):
     __tablename__='location_tbl'
     id=db.Column(db.Integer,db.Sequence('seq_location',start=1001),primary_key=True)
     name=db.Column(db.String(25))
     email=db.Column(db.String(25))
     phoneno=db.Column(db.String(25))
     address=db.Column(db.String(50))
     pincode=db.Column(db.String(25))
     me=db.relationship("menu",back_populates="loc")
     def __repr__(self):
          return "<location({},{},{},{},{},{})>".format(self.id,self.name,self.email,self.phoneno,self.address,self.pincode)'''
@app.route('/')
def home():
     return render_template("index.html")

@app.route('/menu',methods=['GET','POST'])
def menus():
     if request.method=='GET':
          return render_template('menu.html')
     '''elif request.method=='POST':
          idly=request.form['idly']
          dosai=request.form['dosai']
          masaldosai=request.form['masaldosai']
          oniondosai=request.form['oniondosai']
          parotta=request.form['parotta']
          chappathi=request.form['chappathi']
          chickennoodles=request.form['ChickenNoodles']
          eggnoodles=request.form['EggNoodles']
          chickenfriedrice=request.form['ChickenFriedRice']
          eggfriedrice=request.form['EggFriedRice']
          chickenbriyani=request.form['ChickenBriyani']
          eggbriyani=request.form['EggBriyani']
          muttonbriyani=request.form['MuttonBriyani']
          chillichicken=request.form['ChilliChicken']
          totalamount=request.form['totalamount']
          m=menu(idly=idly,dosai=dosai,masaldosai=masaldosai,oniondosai=oniondosai,parotta=parotta,chappathi=chappathi,chickennoodles=chickennoodles,eggnoodles=eggnoodles,chickenfriedrice=chickenfriedrice,eggfriedrice=eggfriedrice,chickenbriyani=chickenbriyani,muttonbriyani=muttonbriyani,eggbriyani=eggbriyani,chillichicken=chillichicken,totalamount=totalamount)
          db.session.add(m)
          db.session.commit()
          l.append(idly)
          return render_template('location.html',value=v)'''
@app.route('/location',methods=['GET','POST'])
def locationfind():
     if request.method=='GET':
          return render_template('location.html')
     elif request.method=='POST':
          idly=request.form['idly']
          dosai=request.form['dosai']
          masaldosai=request.form['masaldosai']
          oniondosai=request.form['oniondosai']
          parotta=request.form['parotta']
          chappathi=request.form['chappathi']
          chickennoodles=request.form['ChickenNoodles']
          eggnoodles=request.form['EggNoodles']
          chickenfriedrice=request.form['ChickenFriedRice']
          eggfriedrice=request.form['EggFriedRice']
          chickenbriyani=request.form['ChickenBriyani']
          eggbriyani=request.form['EggBriyani']
          muttonbriyani=request.form['MuttonBriyani']
          chillichicken=request.form['ChilliChicken']
          totalamount=request.form['totalamount']
          empty.m=menu(idly=idly,dosai=dosai,masaldosai=masaldosai,oniondosai=oniondosai,parotta=parotta,chappathi=chappathi,chickennoodles=chickennoodles,eggnoodles=eggnoodles,chickenfriedrice=chickenfriedrice,eggfriedrice=eggfriedrice,chickenbriyani=chickenbriyani,muttonbriyani=muttonbriyani,eggbriyani=eggbriyani,chillichicken=chillichicken,totalamount=totalamount)
          db.session.add(empty.m)
          db.session.commit()
          empty.id=db.session.query(menu).order_by(menu.id.desc()).first().id
          #val=sum([idly,dosai,masaldosai,oniondosai,parotta,chappathi,chickennoodles,eggnoodles,chickenfriedrice,eggfriedrice,chickenbriyani,eggbriyani,muttonbriyani,chillichicken])
          return render_template('location.html')
          
@app.route('/orders')
def orders():
     #a=db.session.query(location).first()
     b=db.session.query(menu).order_by(menu.id.desc()).first()
     #a1="<h1>location:</h1><p>{}<br>{}<br>{}<br>{}<br>{}<br>{}</p>".format(a.id,a.name,a.email,a.phoneno,a.address,a.pincode)
     #b1="<h1>Menu</h1><p>{}<br>{}<br>{}</p>".format(b.idly,b.dosai,b.name)
     return render_template('order.html',b=b)
@app.route('/contact')
def contact():
     return render_template('contact.html')
@app.route('/thankyou',methods=['GET','POST'])
def thankyou():
     if request.method=='POST':
               v={}
               v['name']=request.form['name']
               v['email']=request.form['email']
               v['phoneno']=request.form['PhoneNumber']
               v['address']=request.form['Address']
               v['pincode']=request.form['pincode']
               #empty.l=location(name=v['name'],email=v['email'],phoneno=v['phoneno'],address=v['address'],pincode=v['pincode'],me=[empty.m])
               #db.session.add(empty.l)
               #db.session.commit()
               db.session.query(menu).filter_by(id=empty.id).update({menu.name:v['name']})
               db.session.query(menu).filter_by(id=empty.id).update({menu.email:v['email']})
               db.session.query(menu).filter_by(id=empty.id).update({menu.phoneno:v['phoneno']})
               db.session.query(menu).filter_by(id=empty.id).update({menu.address:v['address']})
               db.session.query(menu).filter_by(id=empty.id).update({menu.pincode:v['pincode']})
               db.session.commit()
               return render_template('thankyou.html')



     

if __name__ == "__main__":
     db.create_all()
     app.run(debug=True,port=8017)
